# WhatsApp Chat Export: comp1110 group
Export date: October 3, 2026 at 12:00 AM

---

## September 27, 2026

[8:13 PM] __Я added You__

[8:13 PM] **Я:** [group-history message]

[8:14 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[8:14 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[8:14 PM] __Someone added You__

[8:14 PM] __Someone added Я__

[8:14 PM] __Я left__

[8:14 PM] **You:** Hello, I just switched to my HK number

[9:53 PM] **Farid gay:** Hey guys, I think that I have an idea. I am not sure that it’s gonna work out, so I decided to share it with you guys. The problem is students having difficulty deciding where they are gonna have their lunch during really short breaks between lectures. I thought that we can build a program that measures on-campus and off-campus restaurants and give the user an estimated time of eating a lunch and coming back to the campus again. For example, let’s say it’s 1pm and you have a lecture at 1:50 pm. The program will give you, an estimate of going to alfafa at that time and coming back again to your class. Maybe we can improve this by taking students’ schedule so that it may pop up a reminder {e.g. you only have 5 mins to get to the lecture) etc. So let me know what do you guys think of this idea? Don’t forget, this is just an idea and we can build other ideas from this.

---

## September 28, 2026

[12:45 AM] **You:** Hello, that is actually a good idea. I think that this is pretty unique too, but we should anyways check related work. I have some project implementation plans in my mind, for this one we could discuss together.

[1:04 AM] **Farid gay:** Really good, what about others? Share your ideas and opinions.

[5:22 PM] **+84 91 103 07 17:** https://docs.google.com/document/d/1vkA3M3c4Q3xVKYmPTJ0NhfmKcz4oFbQxDQbZPYLWG7w/edit?usp=sharing

[5:23 PM] **+84 91 103 07 17:** hi guys, these are some of my ideas. it was just brainstorm so there weren't much yet

[5:23 PM] **+84 91 103 07 17:** still i think it was a bit broad

---

## September 29, 2026

[11:44 AM] **Farid gay:** I read this but I didn’t understand it

[11:45 AM] **Farid gay:** Maybe you can explain it more explicitly

[11:45 AM] **Farid gay:** We have 6 days left

[11:45 AM] **Farid gay:** Let’s say 3 days for building project plan

[11:45 AM] **Farid gay:** We have 2-3 days to decide

[11:46 AM] **Farid gay:** Present your problem and your solution to that idea more clearly

[11:46 AM] **Farid gay:** Then we can discuss

[12:01 PM] **+84 91 103 07 17:** okay i will send it again tonight

[12:15 PM] **Farid gay:** Appreciate it

[10:02 PM] **+84 91 103 07 17:**
> _+84 91 103 07 17: https://docs.google.com/document/d/1vkA3M3c4Q3xVKYmPTJ0NhfmKcz4oFbQxDQbZPYLWG7w/edit?usp=sharing_
i have updated the ideas

[11:22 PM] **Farid gay:** I have looked throught your ideas. I want us to discuss idea 1 and idea 4 from these ideas. Because both idea 2 and idea 3 are asking a question “why is this like this?”. I don't think we should build a project that explains why something happens. In fact, I think we should pick a specific problem and find a solution using computing and data science rather than explaining why does it happen. Also, I eliminated idea 5 because it says that students often sleep late because of homework, assignments and a lot of uni stuff. And also it presents a biological clock. I think this doesn't make sense because knowing their biological clock doesn't solve assignments or prepare them for quizzes. So even if students know their biological clock, they would probably still sleep late in order to study.

[11:29 PM] **Farid gay:** Coming to idea 1, the problem selection is actually quite good. But I am not really sure if we can think of a solution and build a project for that as freshman in CS or not. Maybe someone can come with a solution, I am totally open for that. And idea 4, the problem is also good here, but I think rather than building only that project, maybe we can make a blend of my idea and your idea 4. It addresses so many student problems in one project. Maybe like, making a map of hku campus and restaurants and uploading that into our project.

[11:30 PM] **+84 91 103 07 17:** yeah i thought so too! It was a bit hard to simulate the whole system and make it work

[11:32 PM] **Farid gay:** yep I like your ideas. So right now, our project plan is not still done. But good thing is that we have some problems and solutions to those problems. But I am still open to others' ideas. In the next 1-2 days please present ideas as much as you can. Maybe we can find a better idea.

---

## September 30, 2026

[8:21 PM] **+852 4473 3181:** Hey guys I came up with an idea as well

[8:22 PM] **+852 4473 3181:** My idea is related to the long queues we face in everyday life, be it at the HKU MTR or at an airport during immigration. I want to use concepts of Data Science in trying to predict which line is the fastest moving. This project isn't as simple as "just pick the shortest line". We can research and take into account many real-world variables such as
time of the day (longer crowds during rush hours)
families per queue ( families finish immigrations faster)
and other things
We could look for and implement an algorithm that can be used to predict the faster queue, or come up with methods on our own.
And we can conduct real experiments (at local MTR stations or HKU restaurant queues) and show "Expected vs Actual" outcomes in our presentation

[8:48 PM] **Farid gay:** that makes sense

[8:51 PM] **Farid gay:** also we can add this project to my idea too. Because it's also about saving students' time. And I also think that solving many problems in a single project is an incredible thing. So like if we add 3 things up, we will have a program that students can use to navigate in campus, find the shortest time to get home in a specific time, and also finding the shortest and the most suitable restaurant for them to have their lunch. It is like an ultimate student guide for hku students. Especially for freshman students this program will definitely be so useful.

[8:51 PM] **Farid gay:** let's hear your opinions about this

---

## October 1, 2026

[9:14 PM] **+84 91 103 07 17:**
> _+852 4473 3181: My idea is related to the long queues we face in everyday life, be it at the HKU MTR or at an airport during immigration. I want to use concepts of Data Science in trying to predict which line is the fastest moving. This project isn't as simple as "just pick the shortest line". We can research and take into account many real-world variables such as
time of the day (longer crowds during rush hours)
families per queue ( families finish immigrations faster)
and other things
We could look for and implement an algorithm that can be used to predict the faster queue, or come up with methods on our own.
And we can conduct real experiments (at local MTR stations or HKU restaurant queues) and show "Expected vs Actual" outcomes in our presentation_
I think that is a good one. Still, there might be many things we are trying to do if we want to implement them at other MTR stations; and at HKU there is one to estimate the crowd too. So I think the restaurant is a better option, and it can merge with the previous idea too.

[9:15 PM] **+84 91 103 07 17:** I think we should decide the final idea tomorrow and start working on the plan to submit on time

[9:15 PM] **Farid gay:**
> _+84 91 103 07 17: I think we should decide the final idea tomorrow and start working on the plan to submit on time_
Yep I was gonna say the same thing

[9:17 PM] **Farid gay:** So If anyone has an idea or an opinion about the ideas

[9:17 PM] **Farid gay:** Please share it

[9:17 PM] **Farid gay:** Because were gonna start to complete project plan tomorrow

[9:17 PM] **Farid gay:** So it is the last chance to share it

[9:25 PM] **+852 4473 3181:**
> _+84 91 103 07 17: I think that is a good one. Still, there might be many things we are trying to do if we want to implement them at other MTR stations; and at HKU there is one to estimate the crowd too. So I think the restaurant is a better option, and it can merge with the previous idea too._
That’s true

[9:27 PM] **+852 4473 3181:** Let’s finalize everything tomorrow then

---

## October 2, 2026

[2:51 AM] **You:** Hello. I think that it is better to have one developed idea rather than trying to merge everything at once. Quality > quantity. Also, quantity doesn't add to creativeness, so if we choose one idea but the most creative idea from those that you proposed it would be better. For data collection, in case of Farid's project with restaurant time estimation, we could try some kind of crowdsourcing - it means making a system that accepts voluntary form submission where each person can submit their restaurant visit, the queue time, food preparation time and exit time. The distance could be measured just by parsing through google maps with exact coordinate, and then just sum all of it up, or if we are going to blend our idea 4 (finding the right way to a class) then we can just directly take the information from there. The only question remains is whether it is possible for us to implement a smart map program, smarter than google maps and hku :)

[4:56 PM] **Farid gay:** great idea

[4:56 PM] **Farid gay:** so any of you guys have an idea of how to build a map?

[4:57 PM] **Farid gay:** that is better than hku's map

[5:32 PM] **Farid gay:** so let's make data collection for the time to go to the restaurants like this: 1) Creating a quick survey for students that how much time was it to come here and go back.And users of the programme reporting the time. 2) Some member(s) of the team will go manually and measure that how much time does it take

[5:32 PM] **Farid gay:** is it okay for u guys?

[5:58 PM] **+852 4473 3181:** Yes but let’s do the project plan first since the deadline is right 😅

[5:59 PM] **Farid gay:** It is the part of a project plan

[6:03 PM] **+84 91 103 07 17:** we can write the outline of the project plan first and then decide who will do each part of it. Maybe set the deadline at some time tomorrow and then we can review together before the deadline. Is that okay with everyone or should we decide what to do first and just write it in?

[6:04 PM] **Farid gay:** Its okay for me

[6:04 PM] **Farid gay:** Let’s set the deadline to 6 pm tomorrow

[6:04 PM] **Farid gay:** We have to finish the plan until that time

[6:05 PM] **Farid gay:** Also we can use AI in order to build a project plan

[6:05 PM] **Farid gay:** We can make AI write it and then review it

[6:12 PM] **+84 91 103 07 17:** okay

[6:12 PM] **+84 91 103 07 17:** https://connecthkuhk-my.sharepoint.com/:w:/g/personal/u3672914_connect_hku_hk/IQC4sMNuoUJYRIBOKec5pDhcAWW0ZLrcmIMaX6U_muA2_TM?e=gvTZNc

[6:13 PM] **+84 91 103 07 17:** here is the file to type the project plan in. can everyone write their names on the part that you want to do? the first part is not count cause we are all gonna do it

[6:14 PM] **Farid gay:** Yeah we can do that

[6:14 PM] **Farid gay:** Rn we are in a lecture

[6:14 PM] **Farid gay:** We can do that this evening

[6:26 PM] **You:**
> _+84 91 103 07 17: https://connecthkuhk-my.sharepoint.com/:w:/g/personal/u3672914_connect_hku_hk/IQC4sMNuoUJYRIBOKec5pDhcAWW0ZLrcmIMaX6U_muA2_TM?e=gvTZNc_
I don't think that those headings need that much effort to be separated between people individually. I will feed the project plan to AI and give you to review. The only section that we would need to fill out ourselves is team roles

[6:26 PM] **Farid gay:**
> _You: I don't think that those headings need that much effort to be separated between people individually. I will feed the project plan to AI and give you to review. The only section that we would need to fill out ourselves is team roles_
Yeah I think that makes sense too

[6:27 PM] **Farid gay:** We would lose so much time writing the project

[6:43 PM] **+84 91 103 07 17:**
> _You: I don't think that those headings need that much effort to be separated between people individually. I will feed the project plan to AI and give you to review. The only section that we would need to fill out ourselves is team roles_
sure!

[11:56 PM] **You:** .
